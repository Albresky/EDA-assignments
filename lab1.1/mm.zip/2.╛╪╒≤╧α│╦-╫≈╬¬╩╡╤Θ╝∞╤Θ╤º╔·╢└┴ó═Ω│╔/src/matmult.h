#define N 16 

void matmult(short int A[N][N],short int B[N][N],int C[N][N]);
